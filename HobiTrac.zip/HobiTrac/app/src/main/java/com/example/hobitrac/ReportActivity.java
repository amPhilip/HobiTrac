package com.example.hobitrac;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class ReportActivity extends AppCompatActivity {
    HobbyDao hobbyDao;
    TextView totalHobbies;
    TextView totalHours;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
        getSupportActionBar().setTitle("Your Hobbies Report");
        getReportData();
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private void getReportData() {

        // totalHobbies = findViewById(R.id.);
        new Thread(new Runnable() {
            int total = 0;
            int totalNumHobbies = 0;
            @Override
            public void run() {
                HobbyDatabase.getInstance(ReportActivity.this).HobbyDao().getAllHobbies().forEach(hobby -> {
                    // totalHours
                    total = (total + hobby.hobby_time);
                    totalHours = findViewById(R.id.lblTotalHours);
                    totalHours.setText(String.valueOf(total) + "Hrs");
                });

                // totalHobbies
                totalHobbies = findViewById(R.id.lblNumHobbies);
                totalNumHobbies = HobbyDatabase.getInstance(ReportActivity.this).HobbyDao().getAllHobbies().size();
                totalHobbies.setText(String.valueOf(totalNumHobbies));

            }
        }).start();
    }
}